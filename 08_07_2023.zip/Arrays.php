<!DOCTYPE html>
<html>
<body>

<?php
$cars = array("Volvo", "BMW", "Toyota");
echo count($cars);
echo "<br>"; 
$car = array("Volvo", "BMW", "Toyota"); 
echo "I like " . $car[0] . ", " . $car[1] . " and " . $car[2] . ".";
echo "<br>"; 
echo "<h1>For Loop In Array</h1>";
$arrlength = count($cars);
for($x = 0; $x < $arrlength; $x++) {
  echo $cars[$x];
  echo "<br>";
}
echo "<br>"; 
echo "<h1>Associative Array</h1>";
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
echo "Peter is " . $age['Peter'] . " years old.";
?>

</body>
</html>

<!DOCTYPE html>
<html>
<body>

<?php
function familyName($fname)
{
  echo "Name Is $fname<br>";
}
familyName("Jani");
familyName("Hege");
function familyName1($fname, $year) 
{
    echo "$fname Was Born in $year <br>";
}
familyName1("Hege","1975");
familyName1("Stale","1978");
//PHP automatically associates a data type to the variable, depending on its value. Since the data types are not set in a strict sense, you can do things like adding a string to an integer without causing an error.
function addNumbers(int $a, int $b)  //PHP is a Loosely Typed Language
{
    return $a + $b;
}
echo addNumbers(5, "5 days");  // since strict is NOT enabled "5 days" is changed to int(5), and it will return 10
function sum(int $x, int $y) 
{
    $z = $x + $y;
    return $z;
}
echo "5 + 10 = " . sum(5,10) . "<br>";
echo "7 + 13 = " . sum(7,13) . "<br>";
?>
</body>
</html>

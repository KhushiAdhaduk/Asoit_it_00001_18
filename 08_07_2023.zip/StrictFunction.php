<?php declare(strict_types=1); // strict requirement
// since strict is enabled and "5 days" is not an integer, an error will be thrown
function addNumbers1(int $a, int $b) 
{
  return $a + $b;
}
echo addNumbers1(5,5); 
?>